#!/bin/sh

git config --global core.autocrlf false
winpty docker run -it -v /$PWD:/tmp/repo artifacts.apps.brd.ro:5012/knesser2/golang:grpc-dev.1.0.1

