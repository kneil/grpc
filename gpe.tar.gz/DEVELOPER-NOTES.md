# Go Files 

Frontend implementation files:

./frontend/grpc.go
./frontend/interface.go

Main app that loads the plugins:
./main.go

Multer plugin implementation:
./multer/grpc.go
./multer/interface.go

Counter plugin wrapper:
./plugin-go-grpc/main.go

Multer plugin wrapper:

./plugin-go-grpc-new/main.go

Frontend proto files:
./proto/frontend/frontend.pb.go
./proto/frontend/frontend_grpc.pb.go

Counter proto files:
./proto/kv/kv.pb.go
./proto/kv/kv_grpc.pb.go

Multer proto files:
./proto/kvb/kvb.pb.go
./proto/kvb/kvb_grpc.pb.go

Counter implementation:
./shared/grpc.go
./shared/interface.go

