// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package frontend

import (
	"context"

	hclog "github.com/hashicorp/go-hclog"
	plugin "github.com/hashicorp/go-plugin"
	// Update this for new plugins:
	proto "github.com/hashicorp/go-plugin/examples/bidirectional/proto/frontend"
	"google.golang.org/grpc"
)

/* Boilerplate stuff */

// GRPCClient is an implementation of KV that talks over RPC.
type GRPCClient struct {
	broker *plugin.GRPCBroker
        // Update this for new plugins
	client proto.FrontendClient
}

/* Plugin method */

// Update this method if it's a new method:
func (m *GRPCClient) Compile(id string, a ConfigHelper) (string,error) {

        hclog.Default().Info("Confirm 2")

	configHelperServer := &GRPCConfigHelperServer{Impl: a}

        aString := "Some output"

	var s *grpc.Server
	serverFunc := func(opts []grpc.ServerOption) (*grpc.Server) {
		s = grpc.NewServer(opts...)
		proto.RegisterConfigHelperServer(s, configHelperServer)

		return s
	}

	brokerID := m.broker.NextId()
	go m.broker.AcceptAndServe(brokerID, serverFunc)

	_, err := m.client.Compile(context.Background(), &proto.CompileRequest{
		ConfigServer: brokerID,
		Id:       id,
	})

	s.Stop()
	return aString, err
}

/* Plugin method */

func (m *GRPCClient) Build(id string) (string, error) {
	resp, err := m.client.Build(context.Background(), &proto.BuildRequest{
		Id: id,
	})
	if err != nil {
		return "", err
	}

	return resp.Output, nil
}

/* Boilerplate stuff */
// Here is the gRPC server that GRPCClient talks to.
type GRPCServer struct {
	// This is the real implementation
	// Update this for new plugins:
	Impl Frontend

	broker *plugin.GRPCBroker
}

/* Plugin method that invokes the 'actual' method - this is a wrapper function for the 'client' */

func (m *GRPCServer) Compile(ctx context.Context, req *proto.CompileRequest) (*proto.CompileResponse, error) {
	conn, err := m.broker.Dial(req.ConfigServer)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	c := &GRPCConfigHelperClient{proto.NewConfigHelperClient(conn)}
	compileOutput :="Compile output"

	hclog.Default().Info("Confirm: 0 - ")

	value, err:= m.Impl.Compile(req.Id,c)

	hclog.Default().Info("Confirm: 1 - ", value)



	return &proto.CompileResponse{Output: compileOutput}, err
}

/* Wrapper function */

func (m *GRPCServer) Build(ctx context.Context, req *proto.BuildRequest) (*proto.BuildResponse, error) {
	v, err := m.Impl.Build(req.Id)
	return &proto.BuildResponse{Output: v}, err
}

// GRPCClient is an implementation of KV that talks over RPC.
type GRPCConfigHelperClient struct{ client proto.ConfigHelperClient }

/* Wrapper function */

func (m *GRPCConfigHelperClient) GetConfig(a string ) (string , error) {
	resp, err := m.client.GetConfig(context.Background(), &proto.ConfigRequest{
		PluginId: a,
	})
	if err != nil {
		hclog.Default().Info("config.GetConfig", "client", "start", "err", err)
		return "", err
	}
	return resp.Output, err
}

// Here is the gRPC server that GRPCClient talks to.
type GRPCConfigHelperServer struct {
	// This is the real implementation
	Impl ConfigHelper
}

/* Wrapper function */

func (m *GRPCConfigHelperServer) GetConfig(ctx context.Context, req *proto.ConfigRequest) (resp *proto.ConfigResponse, err error) {
	r, err := m.Impl.GetConfig(req.PluginId)
	if err != nil {
		return nil, err
	}
	return &proto.ConfigResponse{Output: r}, err
}
