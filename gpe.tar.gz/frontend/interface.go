// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

// Package shared contains shared data between the host and plugins.
package frontend

import (
	"context"

	"google.golang.org/grpc"

	"github.com/hashicorp/go-plugin"
	proto "github.com/hashicorp/go-plugin/examples/bidirectional/proto/frontend"
)

// Handshake is a common handshake that is shared by plugin and host.
var Handshake = plugin.HandshakeConfig{
	ProtocolVersion:  1,
	MagicCookieKey:   "BASIC_PLUGIN",
	MagicCookieValue: "hello",
}

// PluginMap is the map of plugins we can dispense.
var PluginMap = map[string]plugin.Plugin{
	"frontend": &FrontendPlugin{},
}

/* Methods we call from main app or from plugin */

// Methods available in the main app
type ConfigHelper interface {
	GetConfig(string) (string, error)
}

// The interface that we're exposing as a plugin.
// Methods available in the plugin
type Frontend interface {
	Compile(id string, c ConfigHelper) (string,error)
	Build(id string) (string, error)
}

/* Define the plugin itself - boiler plate stuff */

// This is the implementation of plugin.Plugin so we can serve/consume this.
// We also implement GRPCPlugin so that this plugin can be served over
// gRPC.
type FrontendPlugin struct {
	plugin.NetRPCUnsupportedPlugin
	// Concrete implementation, written in Go. This is only used for plugins
	// that are written in Go.
	Impl Frontend
}

/* More boiler plate stuff */

func (p *FrontendPlugin) GRPCServer(broker *plugin.GRPCBroker, s *grpc.Server) error {
	proto.RegisterFrontendServer(s, &GRPCServer{
		Impl:   p.Impl,
		broker: broker,
	})
	return nil
}

func (p *FrontendPlugin) GRPCClient(ctx context.Context, broker *plugin.GRPCBroker, c *grpc.ClientConn) (interface{}, error) {
	return &GRPCClient{
		client: proto.NewFrontendClient(c),
		broker: broker,
	}, nil
}

var _ plugin.GRPCPlugin = &FrontendPlugin{}
