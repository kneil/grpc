# BRD specific stuff

The vendor directory allows us to build inside BRD.

Using a git-bash terminal invoke the 'run' script.

Once inside the container you can:

compile - compile proto 
compile - compile protob

For some reason the package gets trashed inside the kv.pb.go files.   Just add 'proto' and 'protob' back in.
Will try and fix this in the compile scripts eventually.

./b # build stuff

export COUNTER_PLUGIN="./counter-go-rpc"
export MULTER_PLUGIN="./multer-go-rpc"
export FRONTEND_PLUGIN="./frontend-go-rpc"

./counter put hello 1
./counter get hello

( and for multer )

./counter mput hello 2
./counter mget hello 

( and for frontend )

./counter frontend

-> this will just show some log messages relating to the fact that build and compile
functionality is being invoked.

Notice that the key stores are separate - one for each plugin. 

# A bit about the changes made to the hashicorp example

Essentially the counter plugin was copied over to a multer plugin - it does the same thing.

Looks like we need separate proto stuff for each plugin plus all the stuff in shared plus 
a main func in it's own rpc folder which is the wrapper used by the plugin binary.

NB these plugins have the same methods etc so we might be able to share the interface between them.
However simplicity the interface etc have been duplicated.    If the plugins were developed in different
repos then we'd probably need duplicated interfaces anyway so I will leave this as is.

compile / compile b does all the hard stuff to get the proto code.

# Counter Example

This example builds a simple key/counter store CLI where the mechanism
for storing and retrieving keys is pluggable. However, in this example we don't
trust the plugin to do the summation work. We use bi-directional plugins to
call back into the main proccess to do the sum of two numbers. To build this example:

```sh
# This builds the main CLI
$ go build -o counter

# This builds the counter plugin written in Go
$ go build -o counter-go-grpc ./plugin-go-grpc

# This builds the multer plugin written in Go
$ go build -o multer-go-grpc ./plugin-go-grpc-new


# This tells the Counter binary to use the "counter-go-grpc" binary and the multer-go-rprc" binary.
$ export COUNTER_PLUGIN="./counter-go-grpc"
$ export MULTER_PLUGIN="./multer-go-grpc"


# Read and write with counter plugin
$ ./counter put hello 1
$ ./counter put hello 1

$ ./counter get hello


# Read and write with multer plugin
$ ./counter mput hello 1
$ ./counter mput hello 1

$ ./counter mget hello

```

### Plugin: plugin-go-grpc

Each plugin uses gRPC to serve a plugin that is written in Go:

```
# This builds the plugin written in Go
$ go build -o counter-go-grpc ./plugin-go-grpc

# This tells the KV binary to use the "kv-go-grpc" binary
$ export COUNTER_PLUGIN="./counter-go-grpc"
```

## Updating the Protocol

If you update the protocol buffers file, you can regenerate the file
using the following command from this directory. You do not need to run
this if you're just trying the example.

For Go:

```sh
$ protoc -I proto/ proto/kv/kv.proto --go_out=plugins=grpc:proto/
```
