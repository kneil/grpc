// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-2.0

package main

import (
	//"encoding/json"
	//"io/ioutil"

	"github.com/hashicorp/go-plugin"
	"github.com/hashicorp/go-plugin/examples/bidirectional/frontend"

)

// Here is a real implementation of KV that writes to a local file with
// the key name and the contents are the value of the key.
type Frontend struct {
}

type data struct {
	Value string
}

/* Plugin method */

func (k *Frontend) Compile(id string, c frontend.ConfigHelper) (string, error) {
	//v, _ := k.Compile(id,c)
	r, err := c.GetConfig(id)
	if err != nil {
	    return "", err
	}

	/* 
	buf, err := json.Marshal(&data{r})
	if err != nil {
		return err
	}
        */

	//fmt.Println(id, r )

	return r, nil

}

/* Plugin method */

func (k *Frontend) Build(key string) (string, error) {
	//dataRaw, err := ioutil.ReadFile("kv2_" + key)
	//if err != nil {
	//	return "", err
//	}

	//data := &data{}
	//err = json.Unmarshal(dataRaw, data)
	//if err != nil {
	//	return "", err
	//}
	return  "Build called", nil
}

/* Exposed available plugin(s) */
func main() {
	plugin.Serve(&plugin.ServeConfig{
		HandshakeConfig: frontend.Handshake,
		Plugins: map[string]plugin.Plugin{
			"frontend": &frontend.FrontendPlugin{Impl: &Frontend{}},
		},

		// A non-nil value here enables gRPC serving for this plugin...
		GRPCServer: plugin.DefaultGRPCServer,
	})
}
