#/bin/sh

chmod +x b
chmod +x fix-links.sh

mkdir -p /tmp/repo/vendor/github.com/hashicorp/go-plugin/examples
rm -f /tmp/repo/vendor/github.com/hashicorp/go-plugin/examples/bidirectional
ln -s /tmp/repo /tmp/repo/vendor/github.com/hashicorp/go-plugin/examples/bidirectional
